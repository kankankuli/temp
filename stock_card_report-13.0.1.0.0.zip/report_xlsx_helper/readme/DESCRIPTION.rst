This module provides a set of tools to facilitate the creation of excel reports with format xlsx.
